<?php
	$con=mysqli_connect('localhost','id3740636_afriza14','afrizafahmi1','id3740636_dbtrayek');
?>