	<section id="content">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-sm-offset-6 col-md-8 col-md-offset-2">
            <div class='alert alert-danger alert-dismissable' style='margin-top:20px'>
				      <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
				      <h4><i class='icon glyphicon glyphicon-remove'></i> Sukses !</h4> Password berhasil diPerbaharui :D</br><a href="?page=login">Login</a>
			      </div>
          </div>
        </div>
      </div>
    </section>