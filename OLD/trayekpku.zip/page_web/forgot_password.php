<?php
  echo $ps;
?>    
    <section id="content">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
            <div class="page-login-form box">
              <h3>
                Your Email
              </h3>
              <form role="form" method="post" class="login-form">
                <div class="form-group">
                  <div class="input-icon">
                    <i class="icon fa fa-envelope"></i>
                    <input type="text" id="sender-email" class="form-control" name="email" placeholder="Email Address">
                  </div>
                </div> 
                <input class="btn btn-common log-btn" type="submit" name="request_pass" value="Send">
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>