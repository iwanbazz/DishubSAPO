<?php
session_start();
unset($_SESSION['c58c1d179d60e7874f8c856f833eedd3-login']); 
unset($_SESSION['c58c1d179d60e7874f8c856f833eedd3-user']); 
header("location:./");
?>