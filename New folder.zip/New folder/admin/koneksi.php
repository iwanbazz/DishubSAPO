<?php
	$con=mysqli_connect('localhost','dishubpku','Diti201210maret','dishub_trayekpku');
?>