<?php
session_start();
unset($_SESSION['039ff002021b487a6725273d02bbf8cf-trayek-admin']); 
header("location:./");
?>